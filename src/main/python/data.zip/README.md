We add the experimental data for the sake of reproducibility. Please always refer to the original sources/papers and cite them appropriately. References can be found in our paper.

VG: Reed et al. (2008), http://www.aifdb.org
WD: Habernal and Gurevych (2015), https://www.informatik.tu-darmstadt.de/ukp/research_6/data/argumentation_mining_1/argument_annotated_user_generated_web_discourse/index.en.jsp
PE: Stab and Gurevych (2017), https://www.informatik.tu-darmstadt.de/ukp/research_6/data/argumentation_mining_1/argument_annotated_essays_version_2/index.en.jsp
OC: Biran and Rambow (2011a), http://www.cs.columbia.edu/~orb/code_data/persuasion_data.zip
WTP: Biran and Rambow (2011b), http://www.cs.columbia.edu/~orb/code_data/persuasion_data.zip
MT: Peldszus and Stede (2015), https://github.com/peldszus/arg-microtexts
